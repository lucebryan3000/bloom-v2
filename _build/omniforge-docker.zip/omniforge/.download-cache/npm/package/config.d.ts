// ensure `@vitest/expect` provides `chai` types
import type {} from '@vitest/expect'
export * from './dist/config.js'
