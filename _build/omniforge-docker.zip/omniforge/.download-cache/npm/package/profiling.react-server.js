'use strict';

throw new Error(
  'react-dom/profiling is not supported in React Server Components.'
);
