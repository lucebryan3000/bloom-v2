#!/usr/bin/env node
import './dist/cli.js'
