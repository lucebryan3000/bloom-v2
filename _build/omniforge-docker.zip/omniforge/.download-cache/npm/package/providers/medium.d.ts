/** @type {import(".").OAuthProvider} */
export default function Medium(options: Partial<import("./oauth").OAuthConfig<any>>): import("./oauth").OAuthConfig<any>;
//# sourceMappingURL=medium.d.ts.map