/** @type {import(".").OAuthProvider} */
export default function Bungie(options: Partial<import("./oauth").OAuthConfig<any>>): import("./oauth").OAuthConfig<any>;
//# sourceMappingURL=bungie.d.ts.map