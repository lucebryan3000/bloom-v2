/** @type {import(".").OAuthProvider} */
export default function Reddit(options: Partial<import("./oauth").OAuthConfig<any>>): import("./oauth").OAuthConfig<any>;
//# sourceMappingURL=reddit.d.ts.map