/** @type {import(".").OAuthProvider} */
export default function Freshbooks(options: Partial<import("./oauth").OAuthConfig<any>>): import("./oauth").OAuthConfig<any>;
//# sourceMappingURL=freshbooks.d.ts.map