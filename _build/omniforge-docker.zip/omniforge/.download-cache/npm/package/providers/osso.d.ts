/** @type {import(".").OAuthProvider} */
export default function Osso(options: Partial<import("./oauth").OAuthConfig<any>>): import("./oauth").OAuthConfig<any>;
//# sourceMappingURL=osso.d.ts.map