/** @type {import(".").OAuthProvider} */
export default function Coinbase(options: Partial<import("./oauth").OAuthConfig<any>>): import("./oauth").OAuthConfig<any>;
//# sourceMappingURL=coinbase.d.ts.map