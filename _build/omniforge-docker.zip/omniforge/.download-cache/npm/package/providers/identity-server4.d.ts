/** @type {import(".").OAuthProvider} */
export default function IdentityServer4(options: Partial<import("./oauth").OAuthConfig<any>>): import("./oauth").OAuthConfig<any>;
//# sourceMappingURL=identity-server4.d.ts.map