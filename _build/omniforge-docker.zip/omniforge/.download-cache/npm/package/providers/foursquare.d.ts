/** @type {import("src/providers").OAuthProvider} */
/** @type {import(".").OAuthProvider} */
export default function Foursquare(options: Partial<import("src/providers").OAuthConfig<any>>): import("src/providers").OAuthConfig<any>;
//# sourceMappingURL=foursquare.d.ts.map