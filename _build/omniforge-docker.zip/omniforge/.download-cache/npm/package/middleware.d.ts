export { default } from "./next/middleware";
export * from "./next/middleware";
//# sourceMappingURL=middleware.d.ts.map