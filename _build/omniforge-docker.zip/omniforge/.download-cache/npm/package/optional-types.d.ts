/* eslint-disable ts/ban-ts-comment */

// @ts-ignore optional peer dep
export type * as jsdomTypes from 'jsdom'

// @ts-ignore optional peer dep
export type * as happyDomTypes from 'happy-dom'
