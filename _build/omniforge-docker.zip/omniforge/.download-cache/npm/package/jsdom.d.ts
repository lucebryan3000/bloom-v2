import type { JSDOM } from 'jsdom'

declare global {
  const jsdom: JSDOM
}
export {}
